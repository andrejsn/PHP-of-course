<?php

$i1 = 1;
$i2 = 2;
$i3 = 3;

// Array
$arr_num = Array(1,2,3);
$arr_string = Array('Windows', 'Linux', 'MacOS');

// print_r ($arr_num);

for ($i = 0; $i < 100; $i=$i+1) {
    echo  $arr_string[$i];
    //echo $i;
    echo '<br>';
}


// dasselbe mit foreach

