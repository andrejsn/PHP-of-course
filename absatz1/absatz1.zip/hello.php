<?php
    echo '<html> <body> Hello world! </body></html>';