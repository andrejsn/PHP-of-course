<?php
    $i = 15; // integer wieviel Haare auf dem Kopf?

    $d = 0.001; // real 

    echo $i;
    echo '<br>';
    echo ( gettype($i));
    echo '<br>';
    echo $d;
    echo '<br>';
    echo ( gettype($d));
    echo '<br>';

    $sum = $i + $d;
    // zu Hause