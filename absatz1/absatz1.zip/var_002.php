<?php

    $name  = 'Hello world';

    echo (gettype($name));