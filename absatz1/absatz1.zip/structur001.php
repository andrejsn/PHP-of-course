<?php

/**
 * Beschreibung
 */


// echo (2 == 2); // true
// echo '<br>';
// echo (2 == '2'); // true
// echo '<br>';
// echo (2 ==='2'); // 
// echo '<br>';
// echo (2 === 2.0); // integer real 
// echo '<br>';
// echo (2 == 2.0); // 
// echo '<br>';
// echo (2 == 2.000001); // 
// echo '<br>';


// ##############################

$geld = true;
$zeit = true;

echo ($geld && $zeit); // 
echo '<br>';
