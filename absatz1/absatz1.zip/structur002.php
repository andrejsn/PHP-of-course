<?php

// ##############################

$geld = false; //true;
$zeit = true;

//echo ($geld && $zeit); // 
echo '<br>';

if  ($geld && $zeit) {
    // true
    echo 'Gehe ich ins Kino!';
    echo '<br>';
} else {
    // false
    echo 'ich gehe nicht ins Kino ;-(';
    echo '<br>';
}

// || - logische OR  oder 



