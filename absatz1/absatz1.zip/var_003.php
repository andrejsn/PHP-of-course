<?php

$var1 = ' ich bin ein String';
$var2 = 15;
$var3 = 0.0001e5;  // dein Hausaufgabe

$var4 = true; // boolean 

// $var1 + $var2 + ...


// echo ???
